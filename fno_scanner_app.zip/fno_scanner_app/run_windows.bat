@echo off
title NSE F&O Scanner
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
  echo Python not found. Install Python 3.10+ from https://www.python.org/downloads/ ^(tick "Add to PATH"^), then run again.
  pause
  exit /b 1
)
if not exist venv (
  echo First run: setting up, please wait...
  python -m venv venv
  call venv\Scripts\activate
  python -m pip install --upgrade pip
  pip install -r requirements.txt
) else (
  call venv\Scripts\activate
)
echo Starting scanner... browser will open automatically.
streamlit run app.py
pause
