# NSE F&O Scanner

Multi-timeframe scanner for all NSE F&O stocks using RSI, Ichimoku (cloud + TK cross) and CPR, with sector view and confluence.

## Run on your computer
- **Windows:** double-click `run_windows.bat`
- **Mac/Linux:** run `./run_mac_linux.sh`

First run installs everything (1-2 min). The app opens at http://localhost:8501.

## Use on your phone (free hosting)
1. Create a free GitHub account, make a new repository, upload all files from this folder (keep `app.py`, `requirements.txt`, `.streamlit/`).
2. Go to https://share.streamlit.io, sign in with GitHub, click **New app**, pick the repo, main file `app.py`, click **Deploy**.
3. Open the app link on your phone and add it to your home screen.

## Docker
```
docker build -t fno-scanner .
docker run -p 8501:8501 fno-scanner
```

## Notes
- Data: Yahoo Finance (can be delayed). Intraday history is limited (1m ~7 days, 5/15/30m ~60 days).
- Stock list is fetched live from NSE; a built-in fallback list is used if that fails.
- For education only. Not investment advice.
