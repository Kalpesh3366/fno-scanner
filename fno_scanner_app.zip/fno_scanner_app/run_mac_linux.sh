#!/usr/bin/env bash
cd "$(dirname "$0")"
command -v python3 >/dev/null || { echo "Install Python 3.10+ first."; exit 1; }
if [ ! -d venv ]; then
  echo "First run: setting up, please wait..."
  python3 -m venv venv
  source venv/bin/activate
  pip install --upgrade pip
  pip install -r requirements.txt
else
  source venv/bin/activate
fi
streamlit run app.py
